#!/usr/bin/env bash
set -euo pipefail
project_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mkdir -p "$project_dir/verification"
cd "$project_dir/verification"
iverilog -V > tool_versions.txt 2>&1
for name in pll vga_ctrl vga_pic vga_must; do
    iverilog -g2012 -Wall -I "$project_dir/sim" -s "${name}_tb" -o "${name}_tb.vvp" \
        "$project_dir"/RTL/*.v "$project_dir/sim/${name}_tb.v" \
        > "${name}_compile.log" 2>&1
    vvp "${name}_tb.vvp" | tee "${name}_test.log"
    grep -q "PASS ${name}_tb" "${name}_test.log"
done
printf '\nAll four testbenches passed. Actual simulation outputs are in verification/.\n'
