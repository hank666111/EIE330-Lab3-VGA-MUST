#!/usr/bin/env python3
"""Render the observed RTL frame and selected actual VCD traces.

Run after run_tests.sh. No image is used as a substitute for checking the RTL.
"""
from __future__ import annotations
import json
import re
from pathlib import Path
import numpy as np
from PIL import Image
from PIL import ImageDraw, ImageFont
import csv

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "verification"

def observed_frame():
    words = np.array([int(s, 16) for s in (OUT / "frame_rgb565.hex").read_text().split()], dtype=np.uint16)
    if words.size != 640 * 480:
        raise ValueError(f"Observed frame has {words.size} pixels; expected 307200")
    words = words.reshape(480, 640)
    red = ((words >> 11) & 31).astype(np.uint32) * 255 // 31
    green = ((words >> 5) & 63).astype(np.uint32) * 255 // 63
    blue = (words & 31).astype(np.uint32) * 255 // 31
    rgb = np.stack((red, green, blue), axis=-1).astype(np.uint8)
    Image.fromarray(rgb, "RGB").save(OUT / "observed_frame.png")
    colours, counts = np.unique(words, return_counts=True)
    summary = {
        "source": "frame_rgb565.hex written from simulated top-level rgb output",
        "width": 640, "height": 480, "pixels": int(words.size),
        "unique_rgb565": {f"{int(c):04X}": int(n) for c, n in zip(colours, counts)},
        "nonzero_pixels": int(np.count_nonzero(words)),
        "glyph_box_starts": [[168,208],[248,208],[328,208],[408,208]],
    }
    (OUT / "observed_frame_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary

def read_vcd(path):
    """Keep timestamped changes, including X intervals from bounded dumping."""
    names, changes, scopes = {}, {}, []
    stamp, scale_ns, body = 0, 1.0, False
    lines = path.read_text().splitlines()
    for i, raw in enumerate(lines):
        line = raw.strip()
        if line.startswith("$timescale"):
            value = line.removeprefix("$timescale").replace("$end", "").strip()
            if not value:
                value = lines[i + 1].strip()
            match = re.search(r"(\d+)\s*(s|ms|us|ns|ps|fs)", value)
            if match:
                scale_ns = int(match[1]) * {"s": 1e9, "ms": 1e6, "us": 1e3, "ns": 1, "ps": 1e-3, "fs": 1e-6}[match[2]]
        if line.startswith("$scope"):
            scopes.append(line.split()[2])
        elif line.startswith("$upscope"):
            scopes.pop()
        elif line.startswith("$var"):
            parts = line.split()
            names[".".join(scopes + [parts[4]])] = parts[3]
            changes.setdefault(parts[3], [])
        elif line.startswith("$enddefinitions"):
            body = True
        elif body:
            if line.startswith("#"):
                stamp = int(line[1:])
            elif line and line[0] in "01xXzZ":
                code = line[1:]
                if code in changes:
                    changes[code].append((stamp * scale_ns, int(line[0]) if line[0] in "01" else np.nan))
            elif line and line[0] in "bB":
                bits, code = line[1:].split()
                if code in changes:
                    changes[code].append((stamp * scale_ns, int(bits, 2) if not re.search("[xXzZ]", bits) else np.nan))
    return names, changes

FIG = OUT / "figures"
FIG.mkdir(exist_ok=True)

def font(size):
    for name in ("/System/Library/Fonts/Supplemental/Arial.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"):
        if Path(name).is_file():
            return ImageFont.truetype(name, size)
    return ImageFont.load_default()

def render_traces(selections, start_ns, end_ns, title, filename, unit="us", expected=None, compact=False):
    width, left, right, top, row_h = (1400,190,65,95,86) if compact else (1800,245,70,95,140)
    plot_bottom, plot_amp, axis_bottom = (58,35,68) if compact else (90,65,102)
    image = Image.new("RGB", (width, top + row_h * len(selections) + 95), "white")
    draw = ImageDraw.Draw(image)
    draw.text((left, 23), title, fill="#1d334b", font=font(26 if compact else 29))
    plot_w = width - left - right
    def px(time): return left + (time - start_ns) * plot_w / (end_ns - start_ns)
    divisor = {"ns": 1, "us": 1000, "ms": 1000000}[unit]
    for signal_index, (label, rows, hex_format) in enumerate(selections):
        before = [r for r in rows if r[0] <= start_ns]
        window = ([before[-1]] if before else []) + [r for r in rows if start_ns < r[0] <= end_ns]
        if not window: raise ValueError(f"No recorded data for {label}")
        window[0] = (start_ns, window[0][1])
        window.append((end_ns, window[-1][1]))
        baseline = top + row_h * signal_index
        finite = [r[1] for r in window if np.isfinite(r[1])]
        ymin, ymax = (min(finite), max(finite)) if finite else (0, 1)
        if ymax <= 1: ymin, ymax = 0, 1
        elif ymin == ymax: ymin, ymax = 0, max(1, ymax)
        def py(value): return baseline + plot_bottom - (value-ymin) * plot_amp / max(1, ymax-ymin)
        draw.text((15, baseline + (28 if compact else 41)), label, fill="#17344e", font=font(24 if compact else 23))
        for tick in range(7):
            t = start_ns + (end_ns-start_ns)*tick/6
            xx = px(t)
            draw.line((xx, baseline + 15, xx, baseline + axis_bottom), fill="#e0e6ed", width=1)
        draw.line((left, baseline + axis_bottom, width-right, baseline + axis_bottom), fill="#8193a5", width=1)
        for index in range(len(window)-1):
            (ta, va), (tb, vb) = window[index:index+2]
            if np.isfinite(va):
                draw.line((px(ta),py(va),px(tb),py(va)),fill="#116bb2",width=3)
                if np.isfinite(vb): draw.line((px(tb),py(va),px(tb),py(vb)),fill="#116bb2",width=3)
                if hex_format and px(tb)-px(ta) > 80:
                    value = f"{int(va):04X}" if hex_format == "hex" else str(int(va))
                    draw.text((px(ta)+5,baseline+2),value,fill="#26384b",font=font(23 if compact else 17))
            else:
                draw.line((px(ta),baseline+60,px(tb),baseline+60),fill="#b5b5b5",width=2)
        if expected and label in expected:
            ref = expected[label]
            pts = [(start_ns + (end_ns-start_ns)*i/1800) for i in range(1801)]
            for i in range(0, len(pts)-3, 6):
                yy = py(ref(pts[i]))
                draw.line((px(pts[i]),yy,px(pts[min(i+3,len(pts)-1)]),yy),fill="#d77a1f",width=2)
        draw.text((width-right+8,baseline+(18 if compact else 21)),str(int(ymax)),fill="#5e7184",font=font(20 if compact else 16))
        draw.text((width-right+8,baseline+(50 if compact else 78)),str(int(ymin)),fill="#5e7184",font=font(20 if compact else 16))
    bottom = top + row_h*len(selections)
    for tick in range(7):
        value = (start_ns+(end_ns-start_ns)*tick/6)/divisor
        draw.text((px(start_ns+(end_ns-start_ns)*tick/6)-40,bottom+7),f"{value:.3f}",fill="#4a6075",font=font(21 if compact else 18))
    draw.text((width//2-140,bottom+42),f"Simulation time ({unit})",fill="#26384b",font=font(23))
    if expected:
        draw.text((left+(150 if compact else 480),61),"Blue: measured VCD   Orange dashed: independent expected level",fill="#465b6d",font=font(21 if compact else 18))
    image.save(FIG / filename)

def waveform(vcd_name, selections, start_ns, end_ns, title, filename, expected=None, compact=False):
    names, changes = read_vcd(OUT/vcd_name)
    traces=[]
    for path,label in selections:
        if path not in names: raise KeyError(f"Signal {path} missing from {vcd_name}")
        hex_format = "hex" if label in ("pix_data", "rgb") else ("dec" if label in ("cnt_h", "cnt_v", "pix_x", "pix_y") else None)
        traces.append((label,changes[names[path]],hex_format))
    csv_dir = OUT/"waveform_csv"
    csv_dir.mkdir(exist_ok=True)
    with (csv_dir/filename.replace(".png",".csv")).open("w",newline="") as stream:
        writer=csv.writer(stream)
        writer.writerow(["time_ns","signal","value"])
        for label,rows,_ in traces:
            before=[r for r in rows if r[0] <= start_ns]
            window=([before[-1]] if before else [])+[r for r in rows if start_ns < r[0] <= end_ns]
            writer.writerows((f"{t:.3f}",label,str(int(v)) if np.isfinite(v) else "dump-disabled") for t,v in window)
    render_traces(traces,start_ns,end_ns,title,filename,expected=expected,compact=compact)

def sync_evidence():
    rows = list(csv.DictReader((OUT/"sync_edges.csv").open()))
    good = [(float(r["time_ns"]),int(r["reset_n"]),int(r["hsync"]),int(r["vsync"])) for r in rows if r["hsync"] in "01" and r["vsync"] in "01" and r["reset_n"] in "01"]
    # Only the two complete frames before the explicit mid-picture reset.
    main = [r for r in good if 25 <= r[0] <= 33600020]
    def edges(column, rising):
        return [b[0] for a,b in zip(main,main[1:]) if a[column] != b[column] and b[column] == int(rising)]
    hr,hf,vr,vf=edges(2,True),edges(2,False),edges(3,True),edges(3,False)
    hp=round(hr[1]-hr[0],3); hw=round(next(t for t in hf if t>hr[0])-hr[0],3)
    vp=round(vr[1]-vr[0],3); vw=round(next(t for t in vf if t>vr[0])-vr[0],3)
    summary={"horizontal_period_ns":hp,"horizontal_high_ns":hw,"vertical_period_ns":vp,"vertical_high_ns":vw,"line_rate_hz":1e9/hp,"frame_rate_hz":1e9/vp,"source":"actual hsync/vsync edge events in sync_edges.csv"}
    if (hp,hw,vp,vw)!=(32000,3840,16800000,64000): raise ValueError(summary)
    (OUT/"measured_timing.json").write_text(json.dumps(summary,indent=2)+"\n")
    render_traces([("hsync",[(r[0],r[2]) for r in good],None)],25000,95000,
                  "Measured horizontal sync: 32.00 us period, 3.84 us high","wave_hsync.png")
    render_traces([("vsync",[(r[0],r[3]) for r in good],None)],0,33700000,
                  "Measured vertical sync: 16.80 ms period","wave_vsync.png",unit="ms")
    render_traces([("vsync",[(r[0],r[3]) for r in good],None)],16780000,16900000,
                  "Measured vertical pulse: 64.00 us = 2 scan lines","wave_vsync_pulse.png")
    return summary

if __name__ == "__main__":
    print(json.dumps(observed_frame(), indent=2))
    print(json.dumps(sync_evidence(), indent=2))
    (FIG/"observed_frame.png").write_bytes((OUT/"observed_frame.png").read_bytes())
    waveform("pll_tb.vcd", [("pll_tb.sys_clk","sys_clk"),("pll_tb.sys_rst_n","reset_n"),("pll_tb.vga_clk","pixel_clk")],
             0,900,"Measured divide-by-two clock and asynchronous reset","wave_pll.png")
    p="vga_must_tb.dut."
    sig=[("vga_must_tb.sys_clk","sys_clk"),(p+"vga_clk","pixel_clk"),(p+"vga_ctrl_inst.cnt_h","cnt_h"),
         (p+"vga_ctrl_inst.rgb_valid","rgb_valid"),(p+"vga_ctrl_inst.pix_data_req","data_req"),(p+"pix_x","pix_x"),
         (p+"pix_data","pix_data"),("vga_must_tb.rgb","rgb")]
    def scan(t): return max(0,int((t+10)//40))%800
    waveform("vga_must_tb.vcd",sig,1125300,1126200,"First active pixels: one-clock data request lead","wave_valid.png",
             expected={"rgb_valid":lambda t:int(144<=scan(t)<784),"data_req":lambda t:int(143<=scan(t)<783)})
    waveform("vga_must_tb.vcd",sig,7788300,7789600,"M bitmap: background, two white cells and the first off cell","wave_bitmap_pixels.png")
    waveform("vga_must_tb.vcd",[("vga_must_tb.sys_rst_n","reset_n"),(p+"vga_clk","pixel_clk"),(p+"vga_ctrl_inst.cnt_h","cnt_h"),(p+"vga_ctrl_inst.cnt_v","cnt_v"),("vga_must_tb.rgb","rgb")],
             41388400,41389000,"Asynchronous reset clears a visible M pixel, then scanning restarts","wave_reset.png")
    waveform("vga_must_tb.vcd",[(p+"vga_clk","pixel_clk"),("vga_must_tb.hsync","hsync"),(p+"vga_ctrl_inst.cnt_h","cnt_h"),(p+"vga_ctrl_inst.cnt_v","cnt_v")],
             31600,32500,"End of a line: horizontal wrap and vertical increment","wave_line_wrap.png")
    waveform("vga_must_tb.vcd",[sig[2],sig[5],sig[4],sig[3],sig[7]],1125300,1126200,
             "Active-window entry: request leads visible video by 40 ns","wave_valid_compact.png",
             expected={"rgb_valid":lambda t:int(144<=scan(t)<784),"data_req":lambda t:int(143<=scan(t)<783)},compact=True)
    waveform("vga_must_tb.vcd",[sig[2],sig[5],sig[6],sig[7]],7788300,7789600,
             "M first row: two white 8-pixel cells, then background","wave_bitmap_pixels_compact.png",compact=True)
