# Primary tool references consulted

Accessed 1 November 2026. The online manuals may describe versions newer than
the locally executed packages; the executed versions are recorded separately
in `Lab3_VGA/build/tool_packages.txt`.

1. S. Williams, "iverilog Command Line Flags," Icarus Verilog documentation.
   https://steveicarus.github.io/iverilog/usage/command_line_flags.html
   Consulted for the `-s` top-module selector, `-I` include directory,
   language-generation flags, output file and warning options.
2. S. Williams, "Simulation Using Icarus Verilog," Icarus Verilog documentation.
   https://steveicarus.github.io/iverilog/usage/simulation.html
   Consulted for the compilation/VVP simulation workflow.
3. YosysHQ, "Design status," Yosys documentation.
   https://yosyshq.readthedocs.io/projects/yosys/en/latest/cmd/index_passes_status.html
   Consulted for `check` (loops, conflicting drivers and undriven used wires),
   `show` (Graphviz schematics), and `stat` (cell/object statistics and JSON).
   Local execution used Yosys 0.33, rather than the current online manual build.
4. Verilator authors, "Overview," Verilator User's Guide.
   https://verilator.org/guide/latest/overview.html
   Consulted to distinguish the HDL-to-C++ model compilation, the C++ wrapper,
   and execution of the resulting simulator. Local version was 5.020.
5. A. Bybell, "GTKWave 3.3 Wave Analyzer User's Guide."
   https://gtkwave.sourceforge.net/gtkwave.pdf
   Consulted for reading VCD traces and using the hierarchy/wave display.
   The downloaded/current manual states 3.3.126+, while the local viewer is
   3.3.116; no newer-only feature is needed for these VCD files.
6. Z. Wang, "Simple VGA Simulator," GitHub repository and bundled student manual.
   https://github.com/pikipity/Simple-VGA-Simulator
   Consulted from the saved course archive for the 50 MHz interface, signal
   mapping, RGB565 output, the 25 MHz divider and simulator support build.
   The saved original C++ source and installed GUI template match SHA-256
   `e80648a63451f0094d63ca743a474242ae01524782590e47fc62c4b28f371666`.

These references describe tools. They do not independently establish that the
student design passed a test; actual results are recorded in the project logs.
