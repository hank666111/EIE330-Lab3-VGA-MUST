#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
iverilog -g2005-sv -Wall -s vga_must -o build/syntax.vvp RTL/*.v \
    > build/syntax.log 2>&1
yosys -Q -T -l build/rtl.log -p '
    read_verilog RTL/pll.v RTL/vga_ctrl.v RTL/vga_pic.v RTL/vga_must.v;
    hierarchy -check -top vga_must;
    proc; opt; check -assert;
    tee -o build/rtl_stats.json stat -json;
    write_json build/rtl_netlist.json;
    show -format svg -prefix build/vga_must_rtl vga_must;
    show -format svg -prefix build/pll_rtl pll;
    show -format svg -prefix build/vga_ctrl_rtl vga_ctrl;
    show -format svg -prefix build/vga_pic_rtl vga_pic;
    synth -top vga_must; check -assert;
    tee -o build/synth_stats.json stat -json;
    write_json build/synth_netlist.json;
' > build/synthesis_stdout.log 2>&1
if grep -Ei '(^|[^a-z])(warning|error):' build/syntax.log build/rtl.log; then
    printf 'Review diagnostics before using the synthesis results.\n' >&2
    exit 1
fi
printf 'Icarus syntax and Yosys hierarchy/synthesis checks passed.\n'
