# EIE330 Lab 3: VGA MUST display

This project displays M, U, S and T simultaneously in a 640 by 480 RGB565 image.
The 50 MHz input is divided to a 25 MHz pixel clock. Each hand-drawn 8 by 8
bitmap occupies a 64 by 64 box; the four colors are white, yellow, cyan and green.

## Reproduce the RTL checks

Extract this archive, enter its Lab3_VGA directory, then run in Ubuntu:

```sh
bash run_tests.sh
python3 verification_images.py
bash scripts/synthesize.sh
```

Required tools are Icarus/VVP, Yosys, Graphviz, Python 3, NumPy and Pillow.
The four testbenches produce VCD files and expected-versus-actual results.
The image script reads measured VCD and pixel data; report waveforms are data
plots rather than GTKWave screenshots. `docs/` contains representative plots,
CSV data, expected layout/timing and generic synthesis results.

Top module: `vga_must`. Inputs: `sys_clk`, `sys_rst_n`; outputs: `hsync`, `vsync`,
`rgb[15:0]`. Reset is active low. The 800 by 525 raster at 25 MHz gives a 32 us
line and 16.8 ms frame (59.5238 Hz), the lab's nominal 640 by 480 at 60 Hz mode.

The timing structure and M bitmap follow the EIE330 Lab 3 materials. U, S and T
use simple hand-drawn block letters. AI assistance was used for RTL, testing,
figures and explanatory text; the work requires group review and understanding.

This public archive contains only the design, testbenches, RTL verification
scripts and simulation/synthesis evidence. The virtual-board runtime and its
local input-handling correction are maintained in the private group review
package. That correction processes queued mouse events and preserves a held
reset; it does not change the RTL. Course handouts, the group report, student
identifiers, recordings and C++ simulator support are not redistributed here.

Functional simulation and generic synthesis do not establish physical FPGA
placement, routing, analog VGA levels or timing closure. Tool references and
executed version records are in `docs/`.
